import 'package:expense_tracker/models/conta.dart';

class ContaRepository {
  List<Conta> listarContas() {
    return [
      Conta(
          id: '1',
          bancoId: 'bb',
          descricao: 'Banco do Brasil',
          tipoConta: TipoConta.contaPoupanca),
      Conta(
          id: '2',
          bancoId: 'bradesco',
          descricao: 'Bradesco',
          tipoConta: TipoConta.contaInvestimento),
      Conta(
          id: '3',
          bancoId: 'caixa',
          descricao: 'Caixa',
          tipoConta: TipoConta.contaCorrente),
      Conta(
          id: '4',
          bancoId: 'itau',
          descricao: 'Itau',
          tipoConta: TipoConta.contaCorrente)
    ];
  }
}
