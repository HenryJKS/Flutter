//logo banco nome banco e nome da conta
import 'package:expense_tracker/models/conta.dart';
import 'package:flutter/material.dart';

class ContaItem extends StatelessWidget {
  final Conta conta;
  const ContaItem({super.key, required this.conta});

  @override
  Widget build(BuildContext context) {
    //Listar contas
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: AssetImage('images/${conta.bancoId}.png'),
      ),
      title: Text(conta.descricao),
      subtitle: Text(
        conta.tipoConta.name,
      ),
    );
  }
}
