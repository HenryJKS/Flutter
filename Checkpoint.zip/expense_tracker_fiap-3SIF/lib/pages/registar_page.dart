// import 2
import 'dart:html';

import 'package:expense_tracker/repository/auth_repository.dart';
import 'package:flutter/material.dart';

class RegistrarPage extends StatefulWidget {
  const RegistrarPage({Key? key}) : super(key: key);

  @override
  _RegistrarPageState createState() => _RegistrarPageState();
}

class _RegistrarPageState extends State<RegistrarPage> {
  final _key = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final senhaController = TextEditingController();
  final senhaConfirmController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Form(
        key: _key,
        child: Scaffold(
          backgroundColor: Colors.white,
          body: Padding(
            padding: const EdgeInsets.all(16.2),
            child: Center(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildBemVindo(),
                    const SizedBox(height: 20),
                    _buildEmail(),
                    const SizedBox(height: 20),
                    _buildSenha(),
                    const SizedBox(height: 20),
                    _buildConfirmarSenha(),
                    const SizedBox(height: 10),
                    _buildButton(),
                    const SizedBox(height: 10),
                    _buildRegistrar(),
                  ]),
            ),
          ),
        ),
      ),
    );
  }

  Text _buildBemVindo() {
    return const Text(
      "Registrar-se",
      textAlign: TextAlign.center,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 26,
      ),
    );
  }

  TextFormField _buildEmail() {
    return TextFormField(
      controller: emailController,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Email Obrigatório';
        } else if (!validarEmail(value)) {
          return 'Email Inválido';
        }
        return null;
      },
      decoration: const InputDecoration(
        border: OutlineInputBorder(),
        hintText: "Digite seu e-mail",
        prefixIcon: Icon(Icons.email_outlined),
      ),
    );
  }

  TextFormField _buildSenha() {
    return TextFormField(
      controller: senhaController,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Senha Obrigatória';
        } else if (value.length < 5 || value.length > 12) {
          return 'Senha deve ter no mínimo 5 caracteres e máximo de 12 caracteres';
        }

        return null;
      },
      obscureText: true,
      decoration: const InputDecoration(
        border: OutlineInputBorder(),
        hintText: "Digite sua senha",
        prefixIcon: Icon(Icons.lock_outline_rounded),
        suffixIcon: Icon(Icons.visibility_outlined),
      ),
    );
    // Icone para ocultar a senha visibility_off_outlined
  }

  TextFormField _buildConfirmarSenha() {
    return TextFormField(
      controller: senhaConfirmController,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Senha Obrigatória';
        } else if (value.length < 5 || value.length > 12) {
          return 'Senha deve ter no mínimo 5 caracteres e máximo de 12 caracteres';
        } else if (value != senhaController.text) {
          return 'Senhas não conferem';
        }

        return null;
      },
      obscureText: true,
      decoration: const InputDecoration(
        border: OutlineInputBorder(),
        hintText: "Confirme sua senha",
        prefixIcon: Icon(Icons.lock_outline_rounded),
        suffixIcon: Icon(Icons.visibility_outlined),
      ),
    );
    // Icone para ocultar a senha visibility_off_outlined
  }

  Widget _buildButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          onTapBtnSignUp();
        },
        child: const Text('Registrar'),
      ),
    );
  }

  Widget _buildRegistrar() {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, '/');
      },
      child: RichText(
          text: TextSpan(children: <InlineSpan>[
            TextSpan(
              text: "Já tem uma conta?",
              style: TextStyle(
                  color: Colors.blueGrey.shade300,
                  fontSize: 12,
                  fontWeight: FontWeight.w400),
            ),
            TextSpan(
              text: ' ',
              style: TextStyle(
                  color: Colors.indigo.shade300,
                  fontSize: 12,
                  fontWeight: FontWeight.w700),
            ),
            TextSpan(
              text: "Login",
              style: TextStyle(
                  color: Colors.lightBlue.shade300,
                  fontSize: 12,
                  fontWeight: FontWeight.w700),
            )
          ]),
          textAlign: TextAlign.center),
    );
  }

  bool validarEmail(String email) {
    const pattern = r'(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)';
    final regExp = RegExp(pattern);
    return regExp.hasMatch(email);
  }

  void _exibirMensagem(String mensagem) {
    final snackbar = SnackBar(content: Text(mensagem));
    ScaffoldMessenger.of(context).showSnackBar(snackbar);
  }

  void onTapBtnSignUp() {
    if (_key.currentState!.validate()) {
      final email = emailController.text;
      final senha = senhaController.text;
      final senhaConfirm = senhaConfirmController.text;

      if (senha != senhaConfirm) {
        _exibirMensagem('Senhas não conferem');
        return;
      }

      AuthRepository()
          .registrar(email, senha)
          .then((value) => {
                if (value)
                  {
                    Navigator.pushNamed(context, '/home'),
                  }
                else
                  {
                    _exibirMensagem('email ja cadastrado'),
                  }
              })
          .catchError((error) {
        _exibirMensagem('Erro ao registrar');
      });
    }
  }
}
