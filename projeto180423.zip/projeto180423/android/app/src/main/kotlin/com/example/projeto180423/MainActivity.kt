package com.example.projeto180423

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
