class Contato {
  String nomeCompleto;
  String email;

 Contato(this.nomeCompleto, this.email);

}