import 'package:flutter/material.dart';

class DashBoardPage extends StatefulWidget {
  const DashBoardPage();

  @override
  State<DashBoardPage> createState() => _DashBoardPageState();
}

class _DashBoardPageState extends State<DashBoardPage> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('DashBoard'));
  }
}
